﻿namespace Star_Wars_API
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            textBox2 = new TextBox();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            textBox18 = new TextBox();
            textBox19 = new TextBox();
            textBox20 = new TextBox();
            listBox1 = new ListBox();
            button3 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "Get Planet";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(265, 14);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 1;
            button2.Text = "Get Person";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(96, 17);
            label1.Name = "label1";
            label1.Size = new Size(54, 15);
            label1.TabIndex = 2;
            label1.Text = "Planet ID";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(156, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(59, 23);
            textBox1.TabIndex = 3;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 47);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 4;
            label2.Text = "Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 77);
            label3.Name = "label3";
            label3.Size = new Size(89, 15);
            label3.TabIndex = 5;
            label3.Text = "Rotation Period";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 109);
            label4.Name = "label4";
            label4.Size = new Size(80, 15);
            label4.TabIndex = 6;
            label4.Text = "Orbital Period";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 142);
            label5.Name = "label5";
            label5.Size = new Size(55, 15);
            label5.TabIndex = 7;
            label5.Text = "Diameter";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 173);
            label6.Name = "label6";
            label6.Size = new Size(48, 15);
            label6.TabIndex = 8;
            label6.Text = "Climate";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 207);
            label7.Name = "label7";
            label7.Size = new Size(44, 15);
            label7.TabIndex = 9;
            label7.Text = "Gravity";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 239);
            label8.Name = "label8";
            label8.Size = new Size(42, 15);
            label8.TabIndex = 10;
            label8.Text = "Terrain";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(12, 267);
            label9.Name = "label9";
            label9.Size = new Size(80, 15);
            label9.TabIndex = 11;
            label9.Text = "Surface Water";
            label9.Click += label9_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(12, 298);
            label10.Name = "label10";
            label10.Size = new Size(65, 15);
            label10.TabIndex = 12;
            label10.Text = "Population";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(346, 18);
            label11.Name = "label11";
            label11.Size = new Size(57, 15);
            label11.TabIndex = 13;
            label11.Text = "Person ID";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(409, 13);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(63, 23);
            textBox2.TabIndex = 14;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(265, 47);
            label12.Name = "label12";
            label12.Size = new Size(39, 15);
            label12.TabIndex = 15;
            label12.Text = "Name";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(265, 77);
            label13.Name = "label13";
            label13.Size = new Size(43, 15);
            label13.TabIndex = 16;
            label13.Text = "Height";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(265, 109);
            label14.Name = "label14";
            label14.Size = new Size(45, 15);
            label14.TabIndex = 17;
            label14.Text = "Weight";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(265, 142);
            label15.Name = "label15";
            label15.Size = new Size(61, 15);
            label15.TabIndex = 18;
            label15.Text = "Hair Color";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(265, 173);
            label16.Name = "label16";
            label16.Size = new Size(61, 15);
            label16.TabIndex = 19;
            label16.Text = "Skin Color";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(265, 207);
            label17.Name = "label17";
            label17.Size = new Size(57, 15);
            label17.TabIndex = 20;
            label17.Text = "Eye Color";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(265, 244);
            label18.Name = "label18";
            label18.Size = new Size(57, 15);
            label18.TabIndex = 21;
            label18.Text = "Birth Year";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(265, 279);
            label19.Name = "label19";
            label19.Size = new Size(45, 15);
            label19.TabIndex = 22;
            label19.Text = "Gender";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(265, 306);
            label20.Name = "label20";
            label20.Size = new Size(70, 15);
            label20.TabIndex = 23;
            label20.Text = "Homeworld";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(115, 47);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 24;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(115, 77);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 25;
            textBox4.TextChanged += textBox4_TextChanged;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(115, 109);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 26;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(115, 142);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(100, 23);
            textBox6.TabIndex = 27;
            textBox6.TextChanged += textBox6_TextChanged;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(115, 173);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(100, 23);
            textBox7.TabIndex = 28;
            textBox7.TextChanged += textBox7_TextChanged;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(115, 207);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(100, 23);
            textBox8.TabIndex = 29;
            textBox8.TextChanged += textBox8_TextChanged;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(115, 236);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(100, 23);
            textBox9.TabIndex = 30;
            textBox9.TextChanged += textBox9_TextChanged;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(115, 267);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(100, 23);
            textBox10.TabIndex = 31;
            textBox10.TextChanged += textBox10_TextChanged;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(115, 298);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(100, 23);
            textBox11.TabIndex = 32;
            textBox11.TextChanged += textBox11_TextChanged;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(372, 48);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(100, 23);
            textBox12.TabIndex = 33;
            textBox12.TextChanged += textBox12_TextChanged;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(372, 77);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(100, 23);
            textBox13.TabIndex = 34;
            textBox13.TextChanged += textBox13_TextChanged;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(372, 109);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(100, 23);
            textBox14.TabIndex = 35;
            textBox14.TextChanged += textBox14_TextChanged;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(372, 142);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(100, 23);
            textBox15.TabIndex = 36;
            textBox15.TextChanged += textBox15_TextChanged;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(372, 173);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(100, 23);
            textBox16.TabIndex = 37;
            textBox16.TextChanged += textBox16_TextChanged;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(372, 207);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(100, 23);
            textBox17.TabIndex = 38;
            textBox17.TextChanged += textBox17_TextChanged;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(372, 236);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(100, 23);
            textBox18.TabIndex = 39;
            textBox18.TextChanged += textBox18_TextChanged;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(372, 267);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(100, 23);
            textBox19.TabIndex = 40;
            textBox19.TextChanged += textBox19_TextChanged;
            // 
            // textBox20
            // 
            textBox20.Location = new Point(372, 298);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(100, 23);
            textBox20.TabIndex = 41;
            textBox20.TextChanged += textBox20_TextChanged;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(529, 43);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(259, 274);
            listBox1.TabIndex = 42;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // button3
            // 
            button3.Location = new Point(529, 12);
            button3.Name = "button3";
            button3.Size = new Size(105, 23);
            button3.TabIndex = 43;
            button3.Text = "Get All Species";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(813, 337);
            Controls.Add(button3);
            Controls.Add(listBox1);
            Controls.Add(textBox20);
            Controls.Add(textBox19);
            Controls.Add(textBox18);
            Controls.Add(textBox17);
            Controls.Add(textBox16);
            Controls.Add(textBox15);
            Controls.Add(textBox14);
            Controls.Add(textBox13);
            Controls.Add(textBox12);
            Controls.Add(textBox11);
            Controls.Add(textBox10);
            Controls.Add(textBox9);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(textBox2);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private TextBox textBox2;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox20;
        private ListBox listBox1;
        private Button button3;
    }
}
