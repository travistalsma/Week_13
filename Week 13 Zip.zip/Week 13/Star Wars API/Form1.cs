using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http;

namespace Star_Wars_API
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void Form1_Load(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            Planet planet = await JSONHelper.GetPlanet(textBox1.Text);
            textBox3.Text = planet.name;
            textBox4.Text = planet.rotation_period;
            textBox5.Text = planet.orbital_period;
            textBox6.Text = planet.diameter;
            textBox7.Text = planet.climate;
            textBox8.Text = planet.gravity;
            textBox9.Text = planet.terrain;
            textBox10.Text = planet.surface_water;
            textBox11.Text = planet.population;
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            Person person = await JSONHelper.GetPerson(textBox2.Text);
            textBox12.Text = person.name;
            textBox13.Text = person.height;
            textBox14.Text = person.mass;
            textBox15.Text = person.hair_color;
            textBox16.Text = person.skin_color;
            textBox17.Text = person.eye_color;
            textBox18.Text = person.birth_year;
            textBox19.Text = person.gender;
            textBox20.Text = person.homeworld;
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            AllSpecies allSpecies = await JSONHelper.GetAllSpecies();
            listBox1.DataSource = allSpecies.results;
            listBox1.DisplayMember = "name";

            //listBox1.DisplayMember = "name" + "classification";
            //listBox1.DisplayMember = "classification";
            //listBox1.DisplayMember = "name, classification";
            //listBox1.DisplayMember = "";
            //listBox1.DisplayMember = allSpecies.results.ToString();
            //listBox1.DisplayMember = allSpecies.ToString();
            //listBox1.DisplayMember = Species;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox20_TextChanged(object sender, EventArgs e)
        {

        }
        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
